package com.wipro.CartMS.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.wipro.CartMS.exception.ResourceNotFoundException;
import com.wipro.CartMS.model.Cart;
import com.wipro.CartMS.repository.CartRepository;

@Service
public class CartService {

	@Autowired
	CartRepository cartRepo;
	
	public Iterable<Cart> getCarts(){
		return cartRepo.findAll();
	}
	
	public Cart addCart(Cart cart) {
		return cartRepo.save(cart);	
	}
	
	public Cart getCart(Integer id) {
		return cartRepo.findById(id)
				.orElseThrow(()->new ResourceNotFoundException("Cart not found with id = "+id));
	}
	
	public ResponseEntity<Cart> deleteCart(Integer id) {
		Cart existing = cartRepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Cart not found with CartID : " + id));
		cartRepo.delete(existing);
		return ResponseEntity.ok().build();
	}
	
	public Cart updateCart(Cart cart, Integer id) {
		Cart existing = cartRepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Cart not found with CartID : " + id));
		existing.setCartID(cart.getCartID());
		existing.setProductID(cart.getProductID());
		existing.setProductName(cart.getProductName());
		existing.setPrice(cart.getPrice());
		return existing;
	}
	
}
