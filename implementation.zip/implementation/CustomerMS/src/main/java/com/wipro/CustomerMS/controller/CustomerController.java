package com.wipro.CustomerMS.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.CustomerMS.model.Customer;
import com.wipro.CustomerMS.service.CustomerService;

@RestController
@RequestMapping("/customers")
public class CustomerController {

	@Autowired
	CustomerService customerService;

	@PostMapping
	public Customer addCustomer(@RequestBody Customer cus) {
		Customer customer = customerService.addCustomer(cus);
		return customer;
	}

	@GetMapping
	public Iterable<Customer> getCustomers() {
		Iterable<Customer> customer = customerService.getCustomers();
		return customer;
	}

	@GetMapping(value = "{customerId}")
	public Customer getCustomer(@PathVariable Integer customerId) {
		Customer customer = customerService.getCustomer(customerId);
		return customer;
	}

	@DeleteMapping("/{cusId}")
	public ResponseEntity<Customer> deleteCustomer(@PathVariable Integer cusId) {
		ResponseEntity<Customer> response = customerService.deleteCustomer(cusId);
		return response;
	}

	@PutMapping("/{cusId}")
	public Customer updateCustomer(@RequestBody Customer cus, @PathVariable Integer cusId) {
		Customer update = customerService.updateCustomer(cus, cusId);
		return update;
	}

}
