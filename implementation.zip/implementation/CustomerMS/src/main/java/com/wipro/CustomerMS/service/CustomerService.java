package com.wipro.CustomerMS.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.wipro.CustomerMS.exception.ResourceNotFoundException;
import com.wipro.CustomerMS.model.Customer;
import com.wipro.CustomerMS.repository.CustomerRepository;

@Service
public class CustomerService {

	@Autowired
	CustomerRepository customerRepo;

	public Iterable<Customer> getCustomers(){
		return customerRepo.findAll();
	}

	public Customer addCustomer(Customer cus) {
		return customerRepo.save(cus);
	}
	
	public Customer getCustomer(Integer id) {
		return customerRepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Customer not found with id : " + id));
	}

	public Customer updateCustomer(Customer cus, Integer id) {
		Customer existing = customerRepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Customer not found with CustomerID : " + id));
		existing.setCustomerID(cus.getCustomerID());
		existing.setCustomerName(cus.getCustomerName());
		existing.setAddress(cus.getAddress());
		existing.setEmail(cus.getEmail());
		return existing;
	}
	public ResponseEntity<Customer> deleteCustomer(Integer id) {
		Customer existing = customerRepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Customer not found with CustomerID : " + id));
		customerRepo.delete(existing);
		return ResponseEntity.ok().build();
	}
}
