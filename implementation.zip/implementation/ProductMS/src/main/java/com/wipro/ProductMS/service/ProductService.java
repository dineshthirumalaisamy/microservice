package com.wipro.ProductMS.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.wipro.ProductMS.exception.ResourceNotFoundException;
import com.wipro.ProductMS.model.Product;
import com.wipro.ProductMS.repository.ProductRepository;

@Service
public class ProductService {

	@Autowired
	ProductRepository productRepo;
	
	public Iterable<Product> getProducts(){
		return productRepo.findAll();
	}
	
	public Product addProduct(Product pro) {
		return productRepo.save(pro);	
	}
	
	public Product getProduct(Integer id) {
		return productRepo.findById(id)
				.orElseThrow(()->new ResourceNotFoundException("product not found with id = "+id));
	}
	
	public ResponseEntity<Product> deleteProduct(Integer id) {
		Product existing = productRepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("product not found with productID : " + id));
		productRepo.delete(existing);
		return ResponseEntity.ok().build();
	}
	
	public Product updateProduct(Product pro, Integer id) {
		Product existing = productRepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Product not found with ProductID : " + id));
		existing.setProductID(pro.getProductID());
		existing.setProductName(pro.getProductName());
		existing.setPrice(pro.getPrice());
		existing.setDescription(pro.getDescription());
		return existing;
	}
}
