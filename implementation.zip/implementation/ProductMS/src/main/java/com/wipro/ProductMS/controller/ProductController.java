package com.wipro.ProductMS.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.ProductMS.model.Product;
import com.wipro.ProductMS.service.ProductService;

@RestController
@RequestMapping("/products")
public class ProductController {
	
	@Autowired
	ProductService productService;
	
	@GetMapping
	public Iterable<Product> getProducts(){
		Iterable<Product> product=productService.getProducts();
		return product;
	}
	
	@PostMapping
	public Product addProduct(@RequestBody Product pro) {
		Product product=productService.addProduct(pro);
		return product;
	}
	
	@GetMapping("{id}")
	public Product getProduct(@PathVariable Integer id) {
		Product product=productService.getProduct(id);
		return product;
	}
	
	@PutMapping("{id}")
	public Product updateProduct(@RequestBody Product pro,@PathVariable Integer id) {
		Product product= productService.updateProduct(pro, id);
		return product;
	}

	@DeleteMapping("/{Id}")
	public ResponseEntity<Product> deleteCustomer(@PathVariable Integer Id) {
		ResponseEntity<Product> response = productService.deleteProduct(Id);
		return response;
	}
}
